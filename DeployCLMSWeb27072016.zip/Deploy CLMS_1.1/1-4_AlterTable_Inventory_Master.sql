USE [TMB_CLMS]


  IF COL_LENGTH('Inventory_Master','AccountNo') IS NULL
 BEGIN
	ALTER TABLE Inventory_Master
	ADD AccountNo nvarchar(10) null
 END
 
  IF COL_LENGTH('Inventory_Master','DocDetail') IS NULL
 BEGIN
 	ALTER TABLE Inventory_Master
	ADD DocDetail nvarchar(3000) null	
 END