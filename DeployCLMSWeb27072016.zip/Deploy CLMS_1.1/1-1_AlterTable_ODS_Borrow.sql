USE [TMB_CLMS]

 IF COL_LENGTH('ODS_Borrow','CreateDate') IS NULL
 BEGIN
	ALTER TABLE ODS_Borrow
	add CreateDate datetime null
 END

  IF COL_LENGTH('ODS_Borrow','ODS_ID') IS NULL
 BEGIN
	ALTER TABLE ODS_Borrow
	add ODS_ID int null
 END
