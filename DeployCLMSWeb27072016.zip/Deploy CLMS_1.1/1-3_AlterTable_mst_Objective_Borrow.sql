USE [TMB_CLMS]
GO


IF COL_LENGTH('mst_Objective_Borrow','SLA_Warning') IS NULL
 BEGIN
	ALTER TABLE mst_Objective_Borrow
	ADD SLA_Warning [int] NULL DEFAULT ((0))
 END

 IF COL_LENGTH('mst_Objective_Borrow','IsPermout') IS NULL
 BEGIN
	ALTER TABLE mst_Objective_Borrow
	ADD IsPermout [bit] NULL DEFAULT ((0))
 END
 
