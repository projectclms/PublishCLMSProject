﻿USE [CLMSDB]
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'ประวัติการฝาก',
		@Menulist_Url = N'Module/WorkFlow/Deposit/Maker/WorkOrderHistory',
		@Menulist_Level = 1,
		@OUID = 2,
		@SEQDisplay = 19
SELECT	'Return Value' = @return_value
GO


DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'ประวัติการอนุมัติ',
		@Menulist_Url = N'Module/WorkFlow/Deposit/Checker/WorkOrderCheckerHistory',
		@Menulist_Level = 1,
		@OUID = 3,
		@SEQDisplay = 4
SELECT	'Return Value' = @return_value
GO


DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'ประวัติการทำรายการเบิก',
		@Menulist_Url = N'Module/WorkFlow/Borrow/Custodian/WorkOrderCheckerHistory',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 39
SELECT	'Return Value' = @return_value
GO


DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'ประวัติการคืนเอกสาร',
		@Menulist_Url = N'Module/WorkFlow/Return/Custodian/WorkOrderCheckerHistory',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 51
SELECT	'Return Value' = @return_value
GO



DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'SLA',
		@Menulist_Url = N'Module/WorkFlow/Monitoring/ConfigSLA.aspx',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 68

SELECT	'Return Value' = @return_value

GO



DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'ประวัติการฝาก',
		@Menulist_Url = N'Module/WorkFlow/Deposit/VendorStaff/WorkOrderHistory',
		@Menulist_Level = 1,
		@OUID = 8,
		@SEQDisplay = 16
SELECT	'Return Value' = @return_value
GO


