use TMB_CLMS

IF COL_LENGTH('ODS_Detail_Borrow','IsManual') IS NULL
 BEGIN
	ALTER TABLE ODS_Detail_Borrow
	ADD IsManual bit NULL DEFAULT ((0))
 END
