use TMB_CLMS

alter table ods_borrow
add ODS_ID int null