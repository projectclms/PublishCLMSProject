USE [TMB_CLMS_UAT]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetLoanType]    Script Date: 13/07/2016 16:44:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Kittimasak
-- Create date: 09/07/2559
-- Description:	Get Data in table mst_LoanType
-- =============================================
CREATE PROCEDURE [dbo].[sp_GetLoanType] 
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT Id
			,Code
			,Name
	FROM mst_LoanType
	ORDER BY Id ASC;
END

GO


