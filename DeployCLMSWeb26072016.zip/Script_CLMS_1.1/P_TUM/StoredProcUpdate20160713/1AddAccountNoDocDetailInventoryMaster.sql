use TMB_CLMS

alter table Inventory_Master
add AccountNo nvarchar(10) null,
DocDetail nvarchar(3000) null