USE [TMB_CLMS]
GO

/****** Object:  StoredProcedure [dbo].[sp_SearchSumWorkOrder]    Script Date: 26/07/2016 17:15:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
ALTER PROCEDURE [dbo].[sp_SearchSumWorkOrder] 
	@SearchString_ID int = Null,
	@SearchKeyword varchar(50) = Null,
	@SearchDate_ID int = Null,
	@SearchDateFrom varchar(10) = Null,
	@SearchDateTo varchar(10) = Null,
	@User_ID int,
	@StatusID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @SQLString nvarchar(MAX);
	Declare @SearchString_Name as varchar(50);
	Declare @SearchDate_Name as varchar(50)
	Declare @Criteria nvarchar(MAX) = '';
	Declare @Criteria2 nvarchar(MAX) = '';

	if @SearchString_ID is null
	set @SearchString_ID = ''
	if @SearchKeyword is null
	set @SearchKeyword = ''
	if @SearchDate_ID is null
	set @SearchDate_ID = ''
	if @SearchDateFrom is null
	set @SearchDateFrom = ''
	if @SearchDateTo is null
	set @SearchDateTo = ''
	if @User_ID is null
	set @User_ID = 0
	if @StatusID is null
	set @StatusID = 0

	set @SearchString_Name =	(select	case when (Select count(Column_name) 
													from [dbo].[ODS_SearchList] 
													where [Screen] = 'E' and SearchType='string' and id=@SearchString_ID)=0 
										then
												''
										else 
												(Select Column_name 
												from [dbo].[ODS_SearchList] 
												where [Screen] = 'E' and SearchType='string'  and id=@SearchString_ID) 
								end)

	set @SearchDate_Name =		(select	case when (Select count(Column_name) 
													from [dbo].[ODS_SearchList] 
													where [Screen] = 'E' and SearchType='date'  and id=@SearchDate_ID)=0 
										then
												''
										else 
												(Select Column_name 
												from [dbo].[ODS_SearchList] 
												where [Screen] = 'E' and SearchType='date' and id=@SearchDate_ID) 
								end)



SET @SQLString = N'select distinct * from 
	(Select SWO.SWO_CODE, '''' as ProductType
	,SWO.SWO_DEPT_ID,'''' as DEPT_NAME_TH
	--,dp.DEPT_NAME_TH
	,SWO.SWO_OWNER_ID,CONCAT(em.HCM_EMP_PREFIX,'' '', em.HCM_EMP_FNAME_TH , '' '' , em.HCM_EMP_LNAME_TH) as OWNER_NAME
	,sect.SECT_NAME_TH as Branch_name
	,CF.FOLDER_QTY as NumOfFolder,CC.NumOfCustomer
	,SWO.SWO_DATE,ws.Name as StatusName 
	,SWO.SWO_ID
	,(select top 1 b.DIV_NAME_TH
		from CLMSDB.dbo.AUTH_HCM_EMP a inner join CLMSDB.dbo.AUTH_DIV b 
		on a.HCM_EMP_DIV=b.DIV_DIV and a.HCM_EMP_DEPT=b.DIV_DEPTID where a.HCM_EMP_USRID=(select top 1 Owner_id from ods_master where SummaryWorkOrderId=SWO.SWO_ID)) as DIV_NAME_TH
	,(  select top 1	CONCAT(cs.Customer_FirstNme_TH,'' '',cs.Customer_LastName_TH) 
	from ODS_SumWO_Master sm
	INNER JOIN ODS_Master wm
	ON wm.SummaryWorkOrderId= sm.SWO_ID 
	LEFT JOIN  [dbo].[CUSTOMER_PROFILE] cs 
	ON cs.CustomerID=wm.WorkOrder_CUSTID 
	INNER JOIN (Select g.ODS_ID
	from (select distinct ODS_ID from [dbo].[ODS_Trans]) g 
	) tr
	ON tr.ODS_ID = wm.ODS_ID
	INNER JOIN [dbo].[ODS_SumWO_Details] sd 
	ON sd.SWODT_WO_ID = wm.ODS_ID
	where sd. ACTIVE=1 and wm.SummaryWorkOrderId=SWO.SWO_ID ) as Customer_Name
	from 
	(Select sm.*,
	[dbo].[getSumWO_Status](sm.SWO_ID) as Status_id 
	from [dbo].[ODS_SumWO_Master] sm 
	INNER JOIN [dbo].[ODS_SumWO_Trans] st 
	ON sm.[SWO_ID] = st.[SWO_ID] 
	where sm.ACTIVE = 1) SWO 
	INNER JOIN [dbo].mst_WorkOrderStatus ws 
	ON SWO.Status_id = ws.Id 
	INNER JOIN (select	[SWODT_SWO_ID],Isnull(Sum(SWODT_FOLDER_QTY),0) as FOLDER_QTY 
				from [dbo].[ODS_SumWO_Details] 
				group by [SWODT_SWO_ID]) CF 
	ON CF.SWODT_SWO_ID = SWO.SWO_ID 
	INNER JOIN (select sd.SWODT_SWO_ID,count(ms.WorkOrder_CUSTName) as NumOfCustomer
				from [dbo].[ODS_Master] ms 
				INNER JOIN [ODS_SumWO_Details] sd 
				on sd.[SWODT_WO_ID] = ms.ODS_ID 
				where [dbo].[getWO_Status](ms.ODS_ID) = ' + convert(char,@StatusID) + '
				 and ms.WorkOrderTypeID <> 3 group by sd.SWODT_SWO_ID) CC 
	ON CC.SWODT_SWO_ID = SWO.SWO_ID 
	--INNER JOIN [CLMSDB].[dbo].[AUTH_DEPT] dp 
	--ON dp.DEPT_ID = SWO.SWO_DEPT_ID 
	INNER JOIN [CLMSDB].[dbo].AUTH_HCM_EMP em 
	ON em.HCM_EMP_EMPID = swo.SWO_OWNER_ID 
	LEFT join [CLMSDB].[dbo].[AUTH_SECT] sect
	on em.HCM_EMP_SECT = sect.SECT_SECT
	where (SWO.Status_id=' + convert(char,@StatusID) + ' )) x '

	select @Criteria = case when @User_ID = 0 then
			  ' where 1=1 '
			else
	          ' where  x.SWO_OWNER_ID = ' + convert(char,@User_ID)
			end
	
	select @Criteria2 = case when @SearchString_Name = '' then  
				'' 
			else 
				 ' and ' + @SearchString_Name + ' like ' + '''%'+ @SearchKeyword +'%''' 
			end
	
	select @Criteria2 = @Criteria2 + case when @SearchDate_Name = '' then  
				'' 
			else 
				 ' and ' + @SearchDate_Name + ' between ' + ''''+ @SearchDateFrom +' 00:00:00.000''' + ' and ' +  ''''+ @SearchDateTo +' 23:59:59.999''' 
			end

    --print @SQLString
	--print @Criteria
	--print @Criteria2

	set @SQLString = @SQLString + @Criteria + @Criteria2 + ' Order By x.SWO_DATE desc'

	print @SQLString

	--select @SQLString
	EXECUTE sp_executesql @SQLString

END


GO


