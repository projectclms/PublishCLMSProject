﻿USE [CLMSDB]
GO
DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงาน',
		@Menulist_Url = N'',
		@Menulist_Level = 0,
		@OUID = 4,
		@SEQDisplay = 70
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานการนำฝากเอกสาร',
		@Menulist_Url = N'Module/WorkFlow/Report/DepositDocument',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 71
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานการเบิกเอกสาร',
		@Menulist_Url = N'Module/WorkFlow/Report/BorrowDocument',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 72
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานการส่งคืนเอกสาร',
		@Menulist_Url = N'Module/WorkFlow/Report/ReturnDocument',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 73
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานเอกสารที่ต้องติดตามให้นำฝาก',
		@Menulist_Url = N'Module/WorkFlow/Report/WaitingToDepositDocument',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 74
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานเอกสารที่ครบกำหนดส่งคืน',
		@Menulist_Url = N'Module/WorkFlow/Report/DocumentReturnDuedate',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 75
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานเอกสารที่รอส่งมอบให้กับผู้เบิก',
		@Menulist_Url = N'Module/WorkFlow/Report/BorrowListForSendToMaker',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 76
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงาน Activity Report',
		@Menulist_Url = N'Module/WorkFlow/Report/ActivityReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 77
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงาน Inventory Report',
		@Menulist_Url = N'Module/WorkFlow/Report/InventoryReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 78
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานงานที่เจ้าหน้าที่ทำเกิน SLA (นำฝาก)',
		@Menulist_Url = N'Module/WorkFlow/Report/OverSlaDepositReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 79
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานงานที่เจ้าหน้าที่ทำเกิน SLA (เบิกยืม)',
		@Menulist_Url = N'Module/WorkFlow/Report/OverSlaBorrowReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 80
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานรายละเอียดลูกค้าตาม Product',
		@Menulist_Url = N'Module/WorkFlow/Report/CustomerProductReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 81
SELECT	'Return Value' = @return_value
GO


DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงาน Cut-off',
		@Menulist_Url = N'Module/WorkFlow/Report/PermoutReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 82
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานเอกสารทั้งหมดภายใต้ลูกค้า 1 ราย',
		@Menulist_Url = N'Module/WorkFlow/Report/CustomerDocumentReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 83
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานสถานะเอกสารคงคลังและปริมาณความจุ',
		@Menulist_Url = N'Module/WorkFlow/Report/InventoryDocumentReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 84
SELECT	'Return Value' = @return_value
GO

DECLARE	@return_value int
EXEC	@return_value = [dbo].[InsertMenuListAndInsertMenuRoleMapOU]
		@Menulist_Caption = N'รายงานติดตามเอกสารสำหรับลูกค้าที่มี Loan outstanding balance = 0',
		@Menulist_Url = N'Module/WorkFlow/Report/LoanOutStandingReport',
		@Menulist_Level = 1,
		@OUID = 4,
		@SEQDisplay = 85
SELECT	'Return Value' = @return_value
GO