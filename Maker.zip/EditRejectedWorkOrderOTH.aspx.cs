﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TMB_CLMS.AppUtils;
using TMB_CLMS.DataAccess.Models;
using TMB_CLMS.DataAccess.Services;
using ClassLibrary;

namespace TMB_CLMS.Module.WorkFlow.Deposit.Maker
{
    public partial class EditRejectedWorkOrderOTH : System.Web.UI.Page
    {
        #region Properties
        private Properties.Settings setting = new Properties.Settings();
        private CustomerDocumentService customerDocumentService = new CustomerDocumentService();
        private DocumentService documentService = new DocumentService();
        private WorkOrderService workOrderService = new WorkOrderService();
        private SendEmailService sendEmailService = new SendEmailService();

        private int _workOrderId;
        private int workOrderId
        {
            get
            {
                if (Request.QueryString["ODS_ID"] != null)
                {
                    int.TryParse(Request.QueryString["ODS_ID"], out _workOrderId);
                }
                else
                {
                    Response.Redirect("WorkOrderDraft.aspx?DocumentType=ALL&ProductType=ALL");
                }
                return _workOrderId;
            }
        }
        #endregion Properties

        #region Page Load
        protected void Page_Load(object sender, EventArgs e)
        {
            this.CheckPageParameter(workOrderId);
            this.InitailDocumentType();

            if (!Page.IsPostBack)
            {
                if (Session["IsAddWorkOrderDocument"] == null)
                {
                    Session["WorkOrderDocumentList"] = null;
                    Session["WorkOrderDocumentListDelete"] = null;
                }
                else
                {
                    if ((bool)Session["IsAddWorkOrderDocument"] == false)
                    {
                        Session["WorkOrderDocumentList"] = null;
                        Session["WorkOrderDocumentListDelete"] = null;
                    }
                }
               
                    this.ShowResult(workOrderId);
               
            }
        }
        #endregion Page Load

        #region Functions
        protected void MessageBox(string message)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("<script type = 'text/javascript'>");
            sb.Append("window.onload=function(){");
            sb.Append("alert('");
            sb.Append(message);
            sb.Append("')};");
            sb.Append("</script>");
            ClientScript.RegisterClientScriptBlock(this.GetType(), "alert", sb.ToString());
        }
        protected void CheckPageParameter(int workOrderId)
        {
            if (workOrderId == 0)
            {
                Response.Redirect("WorkOrderCheckerRejected.aspx?DocumentType=ALL&ProductType=ALL");
            }
            hdnOsdId.Value = workOrderId.ToString();
        }
        protected void InitailDocumentType()
        {
            //ddlDocumentType.Items.Add(new ListItem("= กรุณาเลือกประเภทเอกสาร =", "0"));
            //ddlDocumentType.SelectedIndex = 0;

            var documentType = documentService.GetDocumentType(25);
            ddlDocumentType.Items.Clear();

            foreach (var item in documentType)
            {
                if (item.DocumentTypeName != "NA")
                {
                    ddlDocumentType.Items.Add(new ListItem(item.DocumentTypeName, item.DocumentTypeId.ToString()));
                }
            }
        }
        protected void ShowResult(int workOrderId)
        {
            var header = workOrderService.GetWorkOrderHeaderReject(workOrderId);
            lblWorkOrderCode.Text = header.WorkOrderCode;
            Literal1.Text = "<a href=\"WorkOrderDetailPrint.aspx?SWO_ID=" + workOrderId + "&CustodianType=" + "" + "\" target=\"_blank\" ><span class=\"glyphicon glyphicon-print\"></span></a>";
            if (header.RejectRemark != null)
            {
                lblRejectRemark.Text = header.RejectRemark;
            }

            List<WorkOrderDocumentModel> documentList;
            if (Session["WorkOrderDocumentList"] != null)
            {
                documentList = (List<WorkOrderDocumentModel>)Session["WorkOrderDocumentList"];
            }
            else
            {
                documentList = workOrderService.GetWorkOrderDocument(workOrderId);
                Session["WorkOrderDocumentList"] = documentList;
            }
            Session["IsAddWorkOrderDocument"] = null;

            StringBuilder sb = new StringBuilder();
            int i = 0;

            foreach (var item in documentList)
            {
                i++;
                sb.Append("<tr>");
                sb.Append(string.Format("<td class=\"text-center\">{0}</td>", i.ToString()));
                sb.Append(string.Format("<td class=\"text-left\">{0}</td>", item.DocumentTypeName));
                sb.Append(string.Format("<td class=\"text-left\">{0}</td>", item.DocumentDetail));
                sb.Append(string.Format("<td class=\"text-center\">{0}</td>", item.DocumentDate.ToString(setting.DateTimeFormat)));
                if (documentList.Count > 0)
                {
                    if (item.IsManual)
                    {
                        sb.Append(string.Format("<td class=\"text-center\"><span class='glyphicon glyphicon-pencil' title='แก้ไข' style='cursor:pointer; padding-left: 5px;' onclick=\"javascript:pupupEdit('{0}','{1}','{2}','{3}');\"></span></td>", item.Id, item.DocumentTypeId, item.DocumentDetail, item.DetailRef));

                    }
                    else
                    {
                        sb.Append(string.Format("<td class=\"text-center\"></td>"));
                    }

                    if (item.IsManual)
                    {
                        sb.Append(string.Format("<td class=\"text-center\"><a href=\"#modalDelete\" data-href=\"DeleteWorkOrderDocument.aspx?id={0}\" data-toggle=\"modal\"><span class=\"glyphicon glyphicon-remove\"></span></a></td>", item.Id));
                    }
                    else
                    {
                        sb.Append(string.Format("<td class=\"text-center\"></td>"));
                    }
                }
                else
                {
                    sb.Append(string.Format("<td class=\"text-center\"></td>"));
                }
                sb.Append("</tr>");
            }

            bodyResult.InnerHtml = sb.ToString();
        }
        #endregion Functions

        #region Actions
        protected void btnSendToApprove_Click(object sender, EventArgs e)
        {
            if (Session["WorkOrderDocumentList"] == null)
            {
                return;
            }

            List<WorkOrderDocumentModel> documentList = (List<WorkOrderDocumentModel>)Session["WorkOrderDocumentList"];
            if (documentList.Count < 1)
            {
                MessageBox("ไม่พบเอกสารสำหรับนำส่ง");
                return;
            }

            int userId = UserUtil.UserId;

            foreach (var item in documentList)
            {
                if (item.IsManual)
                {

                    if (item.Id == 0)
                    {
                        string documentDetail = item.DocumentDetail;
                        workOrderService.AddDocumentToWorkOrder(workOrderId, "", "", item.DocumentDetail, item.DocumentTypeId, userId, item.DetailRef, "", item.IsManual);
                    }
                    else
                    {
                        workOrderService.UpdateDocumentOTHByDocumentID(item.DocumentID, item.DocumentTypeId, item.DocumentDetail, item.DetailRef);
                    }

                    if (!string.IsNullOrEmpty(item.CustomerName))
                    {
                        workOrderService.UpdateCustomerNameODSMasterByODSID(workOrderId, item.CustomerName);
                    }
                }              
            }

            workOrderService.UpdateWorkOrderStatus(workOrderId, (int)WorkOrderStatus.WaitForApprove, userId);

            //Start Send Email to Approvel
            SendMail sendmail = new SendMail();
            try
            {
                //var mailFromDetail = sendEmailService.GetEmailFromList(int.Parse(Session["USRID"].ToString()));
                var mailToDetail = sendEmailService.GetEmailToList(int.Parse(Session["USRID"].ToString()));
                string mailFrom = mailToDetail.userEmail.ToString().Trim();
                string mailTo = mailToDetail.managerEmail.ToString().Trim();
                string mailCC = "";
                string mailBCC = "";
                string mailServer = Other.MailServer;
                string mailServerPort = Other.MailServerPort;
                string fromToMessage = "คุณ" + mailToDetail.managerFname.ToString().Trim() + " " + mailToDetail.managerLname.ToString().Trim();
                string subjectMessage = "การขออนุมัติการนำฝากเอกสาร";
                string detailMessage = "ขออนุมัตินำฝากเอกสารจำนวน " + documentList.Count + " รายการ <br/><br/> <b>กรุณาเข้าระบบ CLMS เพื่อทำรายการอนุมัติ</b>";
                string referenceFromCaption = "ข้อมูลผู้ขออนุมัติ";
                string referenceEmailCaption = "อีเมล์ผู้ขออนุมัติ";
                string referenceTelCaption = "เบอร์ติดต่อของผู้ขออนุมัติ";
                string referenceFrom = "คุณ" + mailToDetail.userFname.ToString().Trim() + " " + mailToDetail.userLname.ToString().Trim();
                string referenceEmail = mailToDetail.userEmail.ToString().Trim();
                string referenceTel = "";

                bool result = sendmail.SendEmail(mailFrom, mailTo, mailCC, mailBCC, mailServer, mailServerPort, fromToMessage, subjectMessage, detailMessage, referenceFromCaption, referenceEmailCaption, referenceTelCaption, referenceFrom, referenceEmail, referenceTel, "", "", Server.MapPath("~/Template/emailTemplate.html"));
            }
            catch (Exception ex)
            {
                Page.ClientScript.RegisterStartupScript(GetType(), "alert", "alert('" + ex.ToString().Trim() + "');", true);
            }


            //End Send Email to Approvel
            Session["WorkOrderDocumentList"] = null;
            Session["WorkOrderDocumentListDelete"] = null;

            if (Request.QueryString["OU_Rejected"] != null)
            {
                if (Request.QueryString["OU_Rejected"] == "Custodian")
                {
                    Response.Redirect("WorkOrderCustodianRejected.aspx?DocumentType=ALL&ProductType=ALL");
                }else{
                    Response.Redirect("WorkOrderCheckerRejected.aspx?DocumentType=ALL&ProductType=ALL");
                }
            }
            else
            {
                Response.Redirect("WorkOrderCheckerWaiting.aspx?DocumentType=ALL&ProductType=ALL");
            }
        }
        protected void btnSaveDraft_Click(object sender, EventArgs e)
        {
            if (Session["WorkOrderDocumentList"] == null)
            {
                return;
            }

            List<WorkOrderDocumentModel> documentList = (List<WorkOrderDocumentModel>)Session["WorkOrderDocumentList"];
            if (documentList.Count < 1)
            {
                MessageBox("ไม่พบเอกสารสำหรับบันทึก");
                return;
            }

            int userId = UserUtil.UserId;

            foreach (var item in documentList)
            {
                if (item.IsManual)
                {

                    if (item.Id == 0)
                    {
                        string documentDetail = item.DocumentDetail;
                        workOrderService.AddDocumentToWorkOrder(workOrderId, "", "", item.DocumentDetail, item.DocumentTypeId, userId, item.DetailRef, "", item.IsManual);
                    }
                    else
                    {
                        workOrderService.UpdateDocumentOTHByDocumentID(item.DocumentID, item.DocumentTypeId, item.DocumentDetail, item.DetailRef);
                    }

                    if(!string.IsNullOrEmpty(item.CustomerName))
                    {
                        workOrderService.UpdateCustomerNameODSMasterByODSID(workOrderId, item.CustomerName);
                    }
                }      
            }

            workOrderService.UpdateWorkOrderStatus(workOrderId, (int)WorkOrderStatus.Draft, userId);

            Session["WorkOrderDocumentList"] = null;
            Session["WorkOrderDocumentListDelete"] = null;

            if (Request.QueryString["OU_Rejected"] != null)
            {
                if (Request.QueryString["OU_Rejected"] == "Custodian")
                {
                    Response.Redirect("WorkOrderCustodianRejected.aspx?DocumentType=ALL&ProductType=ALL");
                }
                else
                {
                    Response.Redirect("WorkOrderCheckerRejected.aspx?DocumentType=ALL&ProductType=ALL");
                }
            }
            else
            {
                //Response.Redirect("EditDraftWorkOrder.aspx?DocumentType=ALL&ProductType=ALL");
                Response.Redirect("WorkOrderDraft.aspx?DocumentType=ALL&ProductType=ALL");
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            if (Session["WorkOrderDocumentList"] != null)
            {
                int userId = UserUtil.UserId;
                List<WorkOrderDocumentModel> documentList = (List<WorkOrderDocumentModel>)Session["WorkOrderDocumentList"];

                foreach (var item in documentList)
                {
                    if (item.IsManual)
                    {
                        documentList.Remove(item);
                    }
                    else
                    {
                        workOrderService.RemoveDocumentFromWorkOrder(workOrderId, item.Id, userId);
                    }
                }

                workOrderService.UpdateWorkOrderStatus(workOrderId, (int)WorkOrderStatus.Cancel, userId);
            }

            if (Request.QueryString["OU_Rejected"] != null)
            {
                if (Request.QueryString["OU_Rejected"] == "Custodian")
                {
                    Response.Redirect("WorkOrderCustodianRejected.aspx?DocumentType=ALL&ProductType=ALL");
                }
                else
                {
                    Response.Redirect("WorkOrderCheckerRejected.aspx?DocumentType=ALL&ProductType=ALL");
                }
            }
            else
            {
                Response.Redirect("WorkOrderCheckerRejected.aspx?DocumentType=ALL&ProductType=ALL");
            }
        }
        #endregion Actions
    }
}